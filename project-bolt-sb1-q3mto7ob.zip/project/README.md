# Shopping Cart Application

This is a React-based shopping cart application that allows users to:
- Add products to their cart
- Update product quantities
- Track progress towards earning a free gift
- Automatically receive a free gift when reaching a spending threshold

## Features

- Product listing with quantity selectors
- Shopping cart with quantity updates and item removal
- Progress tracking towards free gift
- Automatic free gift addition when threshold is reached
- Responsive design

## Running the Project

1. Install dependencies:
```bash
npm install
```

2. Start the development server:
```bash
npm run dev
```

3. Open your browser and navigate to the local server URL provided in the terminal.

## Technical Details

- Built with React and TypeScript
- Styled with Tailwind CSS
- Uses Lucide React for icons
- Implements React hooks for state management